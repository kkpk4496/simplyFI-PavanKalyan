class Graph {
  constructor() {
    this.adjacencyList = new Map();
  }

  addNode(city) {
    this.adjacencyList.set(city, []);
  }

  addEdge(source, destination) {
    this.adjacencyList.get(source).push(destination);
  }

  findRoute(start) {
    const visited = new Set();
    const route = [];

    const dfs = (city) => {
      visited.add(city);
      route.push(city);

      if (city === 'Amsterdam') {
        return true; // Found the destination
      }

      for (const neighbor of this.adjacencyList.get(city)) {
        if (!visited.has(neighbor) && dfs(neighbor)) {
          return true;
        }
      }

      route.pop();
      return false;
    };

    dfs(start);

    return route;
  }
}

// Create a graph and add cities and ticket connections
const graph = new Graph();
const cities = ['Amsterdam', 'Kiev', 'Zurich', 'Prague', 'Berlin', 'Barcelona'];

for (const city of cities) {
  graph.addNode(city);
}

const tickets = [
  ['Kiev', 'Prague'],
  ['Prague', 'Zurich'],
  ['Zurich', 'Amsterdam'],
  ['Amsterdam', 'Barcelona'],
  ['Kiev', 'Berlin'],
  ['Berlin', 'Kiev'],
  ['Berlin', 'Amsterdam'],
  ['Barcelona', 'Berlin'],
];

for (const [source, destination] of tickets) {
  graph.addEdge(source, destination);
}

// Find the route starting from Kiev
const route = graph.findRoute('Kiev');
console.log('Route:', route.join(' -> '));